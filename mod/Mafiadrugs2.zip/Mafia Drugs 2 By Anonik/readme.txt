English

Mafia drugs 2 has arrived!


This is my first mod / mission for GTA V any help is welcome 
by writing to this address:
support.mfdr@gmail.com

Required :

 BUILD A MISSION : https://www.gta5-mods.com/scripts/build_a_mission 
 OPEN ALL INTERIOS : https://www.gta5-mods.com/scripts/open-all-interiors 
 SCRIPT-HOOK-V : https://www.gta5-mods.com/tools/script-hook-v 
 SCRIPT-HOOK-V-NET : https://www.gta5-mods.com/tools/scripthookv-net 
 NATIVE UI : http://gtaforums.com/topic/809284-net-nativeui/ 

Installation :

this mod requires first the installation of build a mission.

1 Extract the File
2 Put the Mafia Drugs 2 folder into your gta v root directory\scripts\bam\mission
3 Put the Mafia Drugs 2.dll file into the scripts folder
4 Open the game
5 Open build a mission
6 Load the mission

Created by Anonik

--------------------------------------------------------------------------------------------

Italian

Mafia drugs 2 has arrived!


Questa � la mia prima mod / missione per GTA V ogni aiuto � benvenuto
scrivendo a questo indirizzo:
support.mfdr@gmail.com

Necessario :

 BUILD A MISSION : https://www.gta5-mods.com/scripts/build_a_mission
 OPEN ALL INTERIORS : https://www.gta5-mods.com/scripts/open-all-interiors
 SCRIPT-HOOK-V : https://www.gta5-mods.com/tools/script-hook-v
 SCRIPT-HOOK-V-NET : https://www.gta5-mods.com/tools/scripthookv-net
 NATIVE UI : http://gtaforums.com/topic/809284-net-nativeui/

Installazione :

questa mod richiede prima l'installazione di build a mission

1 Estrai il file
2 Inserisci la cartella Mafia Drugs 2 nella tua directory root gta v \ scripts \ bam \ mission
3 Inserisci il file di Mafia Drugs 2.dll nella cartella scripts
4 Apri il gioco
5 Apri build a mission
6 Carica la missione

Creata da Anonik